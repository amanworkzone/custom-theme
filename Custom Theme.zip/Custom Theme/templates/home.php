<?php 
/*
 Template Name: Home
*/
get_header();  ?>

	<!-- add here code-->
     
<?php get_footer(); ?>